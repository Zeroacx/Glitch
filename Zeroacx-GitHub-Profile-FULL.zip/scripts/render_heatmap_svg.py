#!/usr/bin/env python3
import json
from pathlib import Path

p = Path("data/contributions.json")
if p.exists():
    data = json.loads(p.read_text())
    levels = [x.get("level",0) for x in data.get("days",[])]
else:
    data = json.loads(Path("data/demo_contributions.json").read_text())
    levels = [x["level"] for x in data]

levels = levels[-371:]
palette = ["#101820","#12352a","#16613c","#20a65a","#39e879"]
svg = '''<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="250" viewBox="0 0 1100 250">
<rect width="1100" height="250" rx="16" fill="#05080b" stroke="#00d9ff"/>
<text x="28" y="36" fill="#00ff88" font-family="monospace" font-size="17">&gt; contribution_matrix</text>
<circle cx="1068" cy="30" r="6" fill="#00ff88"/>
<text x="110" y="72" fill="#7f91a5" font-family="monospace" font-size="12">Jan</text>
<text x="300" y="72" fill="#7f91a5" font-family="monospace" font-size="12">Mar</text>
<text x="490" y="72" fill="#7f91a5" font-family="monospace" font-size="12">May</text>
<text x="680" y="72" fill="#7f91a5" font-family="monospace" font-size="12">Jul</text>
<text x="870" y="72" fill="#7f91a5" font-family="monospace" font-size="12">Sep</text>
<text x="1010" y="72" fill="#7f91a5" font-family="monospace" font-size="12">Nov</text>
'''
for i, level in enumerate(levels):
    x, y = i // 7, i % 7
    if x >= 53: break
    svg += f'<rect x="{70+x*19}" y="{85+y*19}" width="14" height="14" rx="3" fill="{palette[int(level)]}"/>'
svg += '''<text x="70" y="226" fill="#607080" font-family="monospace" font-size="11">Less</text>
<rect x="105" y="216" width="12" height="12" rx="2" fill="#101820"/><rect x="122" y="216" width="12" height="12" rx="2" fill="#12352a"/><rect x="139" y="216" width="12" height="12" rx="2" fill="#16613c"/><rect x="156" y="216" width="12" height="12" rx="2" fill="#20a65a"/><rect x="173" y="216" width="12" height="12" rx="2" fill="#39e879"/>
<text x="193" y="226" fill="#607080" font-family="monospace" font-size="11">More</text>
<text x="790" y="226" fill="#607080" font-family="monospace" font-size="11">ZEROACX // LIVE CONTRIBUTION DATA</text></svg>'''
Path("contrib-heatmap.svg").write_text(svg)
print("Rendered contrib-heatmap.svg")
