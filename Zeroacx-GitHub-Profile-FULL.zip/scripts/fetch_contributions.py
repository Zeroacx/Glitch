#!/usr/bin/env python3
import json, os, sys, urllib.request

TOKEN = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")
USERNAME = os.environ.get("GITHUB_USERNAME", "Zeroacx")

if not TOKEN:
    sys.exit("GH_TOKEN/GITHUB_TOKEN is required")

query = '''
query($login:String!) {
  user(login:$login) {
    contributionsCollection {
      contributionCalendar {
        totalContributions
        weeks {
          contributionDays {
            date
            contributionCount
            contributionLevel
          }
        }
      }
    }
  }
}
'''
payload = json.dumps({"query":query,"variables":{"login":USERNAME}}).encode()
req = urllib.request.Request(
    "https://api.github.com/graphql",
    data=payload,
    headers={"Authorization":f"bearer {TOKEN}","Content-Type":"application/json","User-Agent":"zeroacx-profile"}
)
with urllib.request.urlopen(req, timeout=30) as r:
    result = json.load(r)

if result.get("errors"):
    raise RuntimeError(result["errors"])

cal = result["data"]["user"]["contributionsCollection"]["contributionCalendar"]
mapping = {"NONE":0,"FIRST_QUARTILE":1,"SECOND_QUARTILE":2,"THIRD_QUARTILE":3,"FOURTH_QUARTILE":4}
days = []
for week in cal["weeks"]:
    for day in week["contributionDays"]:
        days.append({"date":day["date"],"count":day["contributionCount"],"level":mapping.get(day["contributionLevel"],0)})

with open("data/contributions.json","w",encoding="utf-8") as f:
    json.dump({"username":USERNAME,"total":cal["totalContributions"],"days":days},f,indent=2)

print("Fetched",len(days),"days; total contributions:",cal["totalContributions"])
